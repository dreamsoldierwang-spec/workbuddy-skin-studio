# WorkBuddy 皮肤包（.wbskin）格式规范 v2.0

## 概述

`.wbskin` 是 WorkBuddy 皮肤的打包文件格式，本质上是一个 **ZIP 压缩包**，仅将文件后缀从 `.zip` 改为 `.wbskin`，便于识别和双击导入。

本规范 v2.0 引入「五层皮肤架构」，支持从单张图片自动生成具有背景氛围、毛玻璃面板、清晰控件和统一 Token 的完整主题。

## 五层皮肤架构

```
┌─────────────────────────────────────────────────────────────┐
│ 5. Assets Layer          装饰资源层（可选插画/动画/水印）      │
├─────────────────────────────────────────────────────────────┤
│ 4. Color Token Layer     主题 Token 层（主色/辅色/状态色）     │
├─────────────────────────────────────────────────────────────┤
│ 3. UI Component Layer    控件组件层（文字/按钮/表单/滚动条）   │
├─────────────────────────────────────────────────────────────┤
│ 2. Container Glass Layer 布局容器面板层（半透明 + 背景模糊）   │
├─────────────────────────────────────────────────────────────┤
│ 1. Background Layer      全局背景层（图片壁纸 / CSS 渐变）     │
└─────────────────────────────────────────────────────────────┘
```

## 文件结构

```
example.wbskin (zip)
├── skin.json          # 必填：元数据、五层配置、文件清单
├── theme.css          # 必填：注入 WorkBuddy 的主样式表
├── layout.css         # 可选：针对特定 DOM 结构的补充样式
├── fonts/
│   └── *.woff2        # 可选：自定义字体文件
└── images/
    ├── hero.png       # 可选：主窗口背景图
    └── ...            # 其他装饰图
```

## skin.json 字段

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `schemaVersion` | string | 是 | 固定 `"2.0"` |
| `id` | string | 是 | 皮肤唯一标识，英文/数字/连字符，如 `"hatsune-miku"` |
| `name` | string | 是 | 显示名称，如 `"初音未来"` |
| `author` | string | 否 | 作者名 |
| `description` | string | 否 | 皮肤简介 |
| `theme` | string | 是 | `"dark"` 或 `"light"` |
| `colors` | object | 否 | 向后兼容的简写配色表，见下 |
| `layers` | object | 否 | 五层高级配置，见下 |
| `fonts` | object | 否 | 字体映射，如 `{ "ui": "fonts/Inter.woff2" }` |
| `files` | object | 是 | 文件清单，见下 |

> **注意**：`layers` 与 `colors` 至少存在一个。当两者同时存在时，`layers` 优先级更高；当只有 `colors` 时，生成器会自动将其推导为等价的五层配置。

### colors（简写配色表，v1 兼容）

| 字段 | 类型 | 说明 |
|------|------|------|
| `accent` | string | 主强调色（按钮、选中、边框） |
| `secondary` | string | 辅助色（悬停、次级按钮） |
| `surface` | string | 基础表面色 |
| `surfaceTransparent` | string | 半透明表面色 |
| `text` | string | 主文字色 |
| `textMuted` | string | 次要文字色 |
| `inputBg` | string | 输入框背景色 |

### layers（五层高级配置）

#### 1. background 全局背景层

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `type` | string | `"image"` | `"image"` 或 `"gradient"` |
| `image` | string | - | 背景图相对路径，如 `"images/hero.png"` |
| `gradient` | string | - | CSS gradient 字符串 |
| `opacity` | number | `1.0` | 背景整体透明度 `0~1` |
| `blur` | number | `0` | 背景模糊 px |
| `scale` | number | `1.0` | 背景缩放 |
| `repeat` | string | `"no-repeat"` | `no-repeat` / `repeat` / `repeat-x` / `repeat-y` |
| `position` | string | `"center"` | 背景位置 |
| `size` | string | `"cover"` | `cover` / `contain` / `100% 100%` |
| `overlay` | string | - | 全局叠色，如 `"rgba(255,255,255,0.12)"` |
| `dimOverlay` | object | - | 压暗/提亮层，见下 |

`dimOverlay`：

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enabled` | boolean | `true` | 是否启用 |
| `start` | string | 自动 | 顶部叠色 |
| `end` | string | 自动 | 底部叠色 |
| `radial` | string | 自动 | 径向叠色 |

#### 2. container 布局容器面板层（毛玻璃）

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `opacity` | number | `0.72` | 通用面板不透明度 `0~1` |
| `blur` | number | `20` | `backdrop-filter: blur(px)` |
| `radius` | number | `16` | 圆角 px |
| `border` | string | - | 边框样式 |
| `shadow` | string | - | 阴影样式 |
| `saturation` | number | `1.15` | 背景饱和度增强 `backdrop-filter: saturate()` |
| `sidebar` | object | - | 左侧边栏专属配置 |
| `panel` | object | - | 中间/右侧面板专属配置 |
| `input` | object | - | 底部输入框专属配置 |
| `header` | object | - | 顶部标题栏专属配置 |
| `popup` | object | - | 弹窗浮层专属配置 |

每个子对象可覆盖：`opacity`、`blur`、`radius`、`border`、`shadow`。

#### 3. component 控件组件层

| 字段 | 类型 | 说明 |
|------|------|------|
| `text` | string | 主文本色 |
| `textMuted` | string | 次要文本色 |
| `textPlaceholder` | string | placeholder 文本色 |
| `link` | string | 链接色 |
| `buttonPrimary` | object | `{ bg, text, hoverBg, hoverText, border }` |
| `buttonSecondary` | object | 同上 |
| `input` | object | `{ bg, text, border, focusBorder, placeholder }` |
| `scrollbar` | object | `{ thumb, track, hover }` |
| `divider` | string | 分割线颜色 |
| `border` | string | 通用边框色 |
| `shadow` | string | 通用控件阴影 |

#### 4. tokens 主题 Token 层

| 字段 | 类型 | 说明 |
|------|------|------|
| `primary` | string | 主色 |
| `secondary` | string | 辅助色 |
| `success` | string | 成功色 |
| `warning` | string | 警告色 |
| `error` | string | 错误色 |
| `surface` | string | 面板实色（fallback） |
| `surfaceSolid` | string | 完全不透明表面色 |
| `background` | string | 与背景层协调的底色 |
| `foreground` | string | 与文字层协调的前景色 |

#### 5. assets 装饰资源层

| 字段 | 类型 | 说明 |
|------|------|------|
| `decorative` | string[] | 装饰图路径数组 |
| `logo` | string | LOGO 替换图路径 |
| `watermark` | string | 水印图路径 |
| `animations` | string[] | CSS 动画类名数组（由 theme.css 实现） |

### files 字段

```json
{
  "css": ["theme.css", "layout.css"],
  "images": {
    "hero": "images/hero.png"
  }
}
```

- `css`：要按顺序注入 WorkBuddy 的 CSS 文件列表。
- `images`：键值对，值为相对于包根的路径。`hero` 为默认主背景图。

## theme.css 编写原则（v2.0）

1. **五层分离**：背景层、容器毛玻璃层、控件层、Token 层、装饰层分别用注释块区分。
2. **全局背景层**：使用 `body::before` 固定全屏，支持 `background-size/position/repeat`，必须 `pointer-events: none`。
3. **毛玻璃容器层**：对侧边栏、主面板、输入框等容器使用 `background: rgba(...)` + `backdrop-filter: blur(...) saturate(...)` + `border-radius` + `border` + `box-shadow`。
4. **文字可读性**：毛玻璃面板上的文字必须高对比，通常 light 主题用深色文字，dark 主题用浅色文字。
5. **控件层**：按钮、输入框、滚动条、标签等需要与 Token 一致，hover/active 状态必须明显。
6. **Token 层**：大量覆盖 `--wb-*` 与 `--vscode-*` 变量，确保 WorkBuddy 原生组件也使用皮肤色值。
7. **资源内联**：注入 WorkBuddy 前，相对路径的图片/字体必须内联为 data URL。

## 导入行为

WorkBuddy 皮肤管理器双击 `.wbskin` 或选择导入时：

1. 解压 `.wbskin` 到 `skins/<id>/`；
2. 校验 `skin.json` 与至少一个 CSS 文件存在；
3. 读取 `skin.json` 显示皮肤信息；
4. 应用时按 `files.css` 顺序读取内容并合并注入 WorkBuddy。
