#!/usr/bin/env node
// 根据 skin.json 生成 theme.css（五层皮肤架构 v2.0）
// 用法：node build-theme-css.js <skin.json路径> <输出theme.css路径>

const fs = require('fs');
const path = require('path');

function hexToRgb(hex) {
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!m) return [128, 128, 128];
  return [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)];
}

function rgbToHex(r, g, b) {
  return '#' + [r, g, b].map((x) => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0')).join('');
}

function luminance([r, g, b]) {
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function chooseTextFor(bgHex) {
  return luminance(hexToRgb(bgHex)) > 160 ? '#111111' : '#ffffff';
}

function withAlpha(hex, alpha) {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function ensureHex(c) {
  if (typeof c !== 'string') return '#888888';
  if (c.startsWith('#')) return c;
  return '#888888';
}

// 从 colors 简表推导五层配置
function deriveLayers(skin) {
  const { theme = 'dark', colors = {}, layers = {}, files = {} } = skin;
  const dark = theme === 'dark';

  const accent = ensureHex(colors.accent || (dark ? '#24C9D7' : '#00c2cb'));
  const secondary = ensureHex(colors.secondary || (dark ? '#EF8FD3' : '#ff6b9d'));
  const surface = ensureHex(colors.surface || (dark ? '#111827' : '#ffffff'));
  const text = ensureHex(colors.text || (dark ? '#F9FAFB' : '#1a1a2e'));
  const textMuted = ensureHex(colors.textMuted || (dark ? '#9CA3AF' : '#4a4a6a'));

  const hasHero = files.images && files.images.hero;

  // 默认背景层
  const defaultBackground = {
    type: hasHero ? 'image' : 'gradient',
    image: hasHero ? files.images.hero : undefined,
    gradient: dark
      ? 'radial-gradient(ellipse at 50% 0%, #1a2634 0%, #0d1117 60%)'
      : 'radial-gradient(ellipse at 50% 0%, #ffffff 0%, #f0f4f8 60%)',
    opacity: 1.0,
    blur: 0,
    scale: 1.0,
    repeat: 'no-repeat',
    position: 'center',
    size: 'cover',
    overlay: dark ? 'rgba(0,0,0,0.18)' : 'rgba(255,255,255,0.10)',
    dimOverlay: {
      enabled: true,
      start: dark ? 'rgba(0,0,0,0.35)' : 'rgba(255,255,255,0.25)',
      end: dark ? 'rgba(0,0,0,0.55)' : 'rgba(255,255,255,0.05)',
      radial: dark ? 'rgba(0,0,0,0.45)' : 'rgba(255,255,255,0.20)'
    }
  };

  // 默认容器层（毛玻璃）—— 透明度要低，让背景壁纸透出来
  const glassBase = {
    solid: dark ? surface : '#ffffff',
    opacity: dark ? 0.46 : 0.72,
    blur: 28,
    saturation: 1.25,
    radius: 16,
    border: dark ? '1px solid rgba(255,255,255,0.10)' : '1px solid rgba(255,255,255,0.45)',
    shadow: dark
      ? '0 8px 32px rgba(0,0,0,0.25)'
      : '0 8px 32px rgba(0,0,0,0.08)'
  };

  const defaultContainer = {
    ...glassBase,
    sidebar: { ...glassBase, opacity: dark ? 0.40 : 0.68, radius: 0 },
    panel: { ...glassBase, opacity: dark ? 0.24 : 0.54, radius: 20 },
    input: { ...glassBase, opacity: dark ? 0.30 : 0.62, radius: 24 },
    header: { ...glassBase, opacity: dark ? 0.38 : 0.68, radius: 0 },
    popup: { ...glassBase, opacity: dark ? 0.96 : 0.97, radius: 16 }
  };

  // 默认控件层
  const defaultComponent = {
    text,
    textMuted,
    textPlaceholder: textMuted,
    link: accent,
    border: dark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.07)',
    divider: dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)',
    shadow: dark ? '0 2px 8px rgba(0,0,0,0.20)' : '0 2px 8px rgba(0,0,0,0.06)',
    buttonPrimary: {
      bg: withAlpha(accent, dark ? 0.16 : 0.12),
      text: accent,
      hoverBg: accent,
      hoverText: chooseTextFor(accent),
      border: withAlpha(accent, dark ? 0.55 : 0.45)
    },
    buttonSecondary: {
      bg: withAlpha(surface, dark ? 0.10 : 0.28),
      text,
      hoverBg: withAlpha(surface, dark ? 0.24 : 0.52),
      hoverText: text,
      border: dark ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.08)'
    },
    input: {
      bg: colors.inputBg || (dark ? withAlpha(surface, 0.22) : withAlpha(surface, 0.55)),
      text,
      border: dark ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.10)',
      focusBorder: accent,
      placeholder: textMuted
    },
    scrollbar: {
      thumb: secondary,
      track: 'transparent',
      hover: accent
    }
  };

  // 默认 Token 层
  const defaultTokens = {
    primary: accent,
    secondary,
    success: '#52c41a',
    warning: '#faad14',
    error: '#f5222d',
    surface,
    surfaceSolid: surface,
    background: surface,
    foreground: text
  };

  // 合并用户 layers
  const merged = {
    background: { ...defaultBackground, ...(layers.background || {}) },
    container: { ...defaultContainer, ...(layers.container || {}) },
    component: { ...defaultComponent, ...(layers.component || {}) },
    tokens: { ...defaultTokens, ...(layers.tokens || {}) },
    assets: layers.assets || {}
  };

  // 递归合并 container 子对象
  for (const key of ['sidebar', 'panel', 'input', 'header', 'popup']) {
    if (layers.container && layers.container[key]) {
      merged.container[key] = { ...defaultContainer[key], ...layers.container[key] };
    }
  }

  // 递归合并 component 子对象
  for (const key of ['buttonPrimary', 'buttonSecondary', 'input', 'scrollbar']) {
    if (layers.component && layers.component[key]) {
      merged.component[key] = { ...defaultComponent[key], ...(layers.component[key] || {}) };
    }
  }

  return merged;
}

function buildTokenVars(layers, dark) {
  const { tokens, component, container } = layers;
  const btnPrimary = component.buttonPrimary;
  const btnSecondary = component.buttonSecondary;
  const input = component.input;

  return `:root,
html, html.light, html.dark,
body, body.light, body.dark,
body.cb-light, body.cb-dark,
body.vscode-light, body.vscode-dark,
body.agent-ui-theme {
  /* ===== WorkBuddy native tokens ===== */
  --wb-color-text-primary: ${component.text};
  --wb-color-text-secondary: ${component.textMuted};
  --wb-color-text-tertiary: ${component.textMuted};
  --wb-sidebar-bg: ${withAlpha(tokens.surface, container.sidebar.opacity)};
  --wb-panel-bg: ${withAlpha(tokens.surface, container.panel.opacity)};
  --wb-chat-bg: ${withAlpha(tokens.surface, container.panel.opacity)};
  --wb-input-bg: ${input.bg};
  --wb-accent: ${tokens.primary};

  --wb-background: ${tokens.background};
  --wb-surface: ${tokens.surface};
  --wb-surface-primary: ${tokens.surface};
  --wb-surface-secondary: ${withAlpha(tokens.surface, container.sidebar.opacity)};
  --wb-surface-tertiary: ${withAlpha(tokens.surface, container.panel.opacity)};
  --wb-main-bg: ${tokens.background};
  --wb-content-bg: ${withAlpha(tokens.surface, container.panel.opacity)};
  --wb-card-bg: ${withAlpha(tokens.surface, container.panel.opacity)};
  --wb-text-primary: ${component.text};
  --wb-text-secondary: ${component.textMuted};
  --wb-text-tertiary: ${component.textMuted};
  --wb-text-link: ${component.link};
  --wb-border: ${component.border};

  /* ===== VS Code / Monaco tokens ===== */
  --vscode-focusBorder: ${tokens.primary};
  --vscode-button-background: ${btnPrimary.bg};
  --vscode-button-hoverBackground: ${btnPrimary.hoverBg};
  --vscode-button-foreground: ${btnPrimary.text};
  --vscode-editor-background: ${tokens.background};
  --vscode-editor-foreground: ${component.text};
  --vscode-sideBar-background: ${withAlpha(tokens.surface, container.sidebar.opacity)};
  --vscode-sideBar-foreground: ${component.text};
  --vscode-activityBar-background: ${withAlpha(tokens.surface, container.sidebar.opacity)};
  --vscode-activityBar-foreground: ${component.text};
  --vscode-foreground: ${component.text};
  --vscode-titleBar-activeBackground: ${withAlpha(tokens.surface, container.header.opacity)};
  --vscode-titleBar-inactiveBackground: ${withAlpha(tokens.surface, container.header.opacity)};
  --vscode-titleBar-activeForeground: ${component.text};
  --vscode-tab-activeBackground: ${withAlpha(tokens.surface, container.panel.opacity)};
  --vscode-tab-inactiveBackground: ${withAlpha(tokens.surface, container.sidebar.opacity)};
  --vscode-tab-activeForeground: ${component.text};
  --vscode-tab-inactiveForeground: ${component.textMuted};
  --vscode-panel-background: ${withAlpha(tokens.surface, container.panel.opacity)};
  --vscode-panel-border: ${component.border};
  --vscode-input-background: ${input.bg};
  --vscode-input-foreground: ${input.text};
  --vscode-input-border: ${input.border};
  --vscode-list-activeSelectionBackground: ${tokens.primary};
  --vscode-list-activeSelectionForeground: ${btnPrimary.text};
  --vscode-list-hoverBackground: ${withAlpha(tokens.secondary, 0.22)};
  --vscode-list-hoverForeground: ${component.text};
  --vscode-list-inactiveSelectionBackground: ${withAlpha(tokens.surface, container.sidebar.opacity)};
  --vscode-list-inactiveSelectionForeground: ${component.text};
  --vscode-scrollbarSlider-background: ${component.scrollbar.thumb};
  --vscode-scrollbarSlider-hoverBackground: ${component.scrollbar.hover};
  --vscode-badge-background: ${tokens.primary};
  --vscode-badge-foreground: ${btnPrimary.text};
  --vscode-progressBar-background: ${tokens.primary};
  --vscode-widget-shadow: ${component.shadow};
}`;
}

function buildBackgroundLayer(layers) {
  const bg = layers.background;
  const bgImage = bg.type === 'image' && bg.image
    ? `url("${bg.image}")`
    : (bg.gradient || 'none');

  const dim = bg.dimOverlay || {};
  const dimEnabled = dim.enabled !== false;

  // Vignette from edges only, so the centre remains the hero image
  const overlayStart = dim.start || bg.overlay || 'transparent';
  const overlayEnd = dim.end || bg.overlay || 'transparent';
  const overlayRadial = dim.radial || bg.overlay || 'transparent';

  const dimGradients = dimEnabled
    ? `radial-gradient(ellipse at 68% 28%, transparent 0%, transparent 34%, ${overlayRadial} 100%),
    linear-gradient(180deg, ${overlayStart} 0%, transparent 34%, transparent 68%, ${overlayEnd} 100%)`
    : `linear-gradient(180deg, ${bg.overlay || 'transparent'} 0%, ${bg.overlay || 'transparent'} 100%)`;

  const solid = (layers.tokens && layers.tokens.surfaceSolid) || '#101014';

  // IMPORTANT (field lesson): a wallpaper on a negative-z pseudo-element behind `body`
  // is always hidden by opaque page roots such as WorkBuddy's `.teams-container` and the
  // hashed `_gridViewItem_*` split-grid items. Use ONE verified visible shell as the sole
  // artwork owner and reset every descendant shell to transparent.
  return `/* ===== 1. Background Layer 全局背景层（放在最后，覆盖一切外壳底色） ===== */
/* 1a. 清空所有不透明外壳 */
html, body, #root, #app, .app, .root, main, .main,
[class*="_grid_"], [class*="gridView"], [class*="gridViewItem"],
.teams-content-wrapper, .teams-main-content,
.main-content, [class*="main-content"],
.conversation-sidebar, .sidebar-next, .sidebar-next-body,
[class*="chatMessage"], [class*="chat-message"], [class*="messageList"],
.group-messages, [class*="assistantMessage"], [class*="assistantTextContent"],
.wb-home-page, .wb-home-page__main-content, [class*="emptyState"], [class*="_emptyState"],
.cb-markdown, [class*="workbench"], [class*="app-root"], [class*="page-root"],
/* 胶囊/分类标签的父级容器不要填充 */
[class*="category"], [class*="categories"], [class*="tag-list"], [class*="tags"],
[class*="chip-group"], [class*="chips"], [class*="pill-group"], [class*="pills"],
[class*="capsule"], [class*="home-row"], [class*="hero-row"], [class*="quick-actions"],
/* 兜底：首页内部所有后代元素一律透明（含背景/边框/阴影），杜绝任何父级背景条。
   胶囊 hover 背景由组件层 [class*="tag"]:hover 等更高特异性规则恢复。 */
.wb-home-page *, [class*="home-page"] *, [class*="homePage"] * {
  background-color: transparent !important;
  background-image: none !important;
  border-color: transparent !important;
  box-shadow: none !important;
}
.wb-home-page, [class*="home-page"], [class*="homePage"],
.monaco-workbench .part, .monaco-editor, .monaco-editor-background {
  background-color: transparent !important;
  background-image: none !important;
  border: none !important;
}

/* 1b. 兜底底色，避免缝隙露出宿主白底 */
html, body {
  background-color: ${solid} !important;
}

/* 1c. 唯一壁纸持有者：真实可见外壳 */
.teams-container,
#root:not(:has(.teams-container)),
body:not(:has(#root)) {
  position: relative !important;
  background-color: ${solid} !important;
  background-image: none !important;
}
.teams-container::before,
#root:not(:has(.teams-container))::before,
body:not(:has(#root))::before {
  content: "";
  position: absolute;
  inset: -10px;
  z-index: 0;
  pointer-events: none;
  background: ${bgImage} ${bg.position}/${bg.size} ${bg.repeat};
  opacity: ${bg.opacity};
  filter: brightness(0.42) saturate(1.12) blur(${Math.max(0, bg.blur - 1)}px);
}
.teams-container::after,
#root:not(:has(.teams-container))::after,
body:not(:has(#root))::after {
  content: "";
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  background: ${dimGradients};
}
/* 1d. 真实内容抬到壁纸之上 */
.teams-container > *,
#root:not(:has(.teams-container)) > *,
body:not(:has(#root)) > * {
  position: relative;
  z-index: 2;
}`;
}

function glassRule(selector, cfg, textColor, mutedColor) {
  const backdrop = `blur(${cfg.blur}px) saturate(${cfg.saturation || 1.15})`;
  return `${selector} {
  background: ${withAlpha(cfg.solid || '#ffffff', cfg.opacity)} !important;
  backdrop-filter: ${backdrop} !important;
  -webkit-backdrop-filter: ${backdrop} !important;
  border-radius: ${cfg.radius}px !important;
  ${cfg.border ? `border: ${cfg.border} !important;` : 'border: none !important;'}
  ${cfg.shadow ? `box-shadow: ${cfg.shadow} !important;` : ''}
  color: ${textColor} !important;
}
${selector} [class*="muted"],
${selector} [class*="secondary"],
${selector} [class*="desc"],
${selector} [class*="timestamp"] {
  color: ${mutedColor} !important;
}`;
}

function buildContainerLayer(layers, dark) {
  const { container, component } = layers;

  // Real WorkBuddy 5.x selectors captured from a live DOM audit (scripts/cdp-selector-map.mjs).
  const sidebarSel = `.conversation-list, .sidebar-next-main-header, [class*="sider"], [class*="nav-bar"], nav`;
  const panelSel = `[class*="panel"]:not([class*="main"]):not([class*="content"]):not([class*="category"]):not([class*="categories"]):not([class*="tag"]):not([class*="tags"]):not([class*="chip"]):not([class*="chips"]):not([class*="pill"]):not([class*="pills"]):not([class*="capsule"]):not([class*="home"]):not([class*="hero"]):not([class*="user"]):not([class*="profile"]):not([class*="account"]):not([class*="member"]):not([class*="avatar"]):not([class*="status"]):not([class*="notification"]):not([class*="settings"]), [class*="message-list"], [class*="detail"], [class*="overview"], [class*="preview"]`;
  const inputSel = `[class*="input-area-container"], [class*="_mainArea_"], [class*="composer"], .input-area, .chat-input`;
  const headerSel = `.workbuddy-topbar, .conversation-list-topbar, [class*="titlebar"], [class*="title-bar"]`;
  const popupSel = `[class*="popup"]:not([class*="user-menu"]), [class*="modal"]:not([class*="user-menu"]), [class*="dropdown"]:not([class*="user-menu"]), [class*="tooltip"]:not([class*="user-menu"]), [class*="menu"]:not([class*="user-menu"]):not([class*="user-"]), [role="menu"]:not([class*="user-menu"]), [role="listbox"]:not([class*="user-menu"]), [role="dialog"]:not([class*="user-menu"])`;

  return `/* ===== 2. Container Glass Layer 布局容器面板层 ===== */
${glassRule(sidebarSel, container.sidebar, component.text, component.textMuted)}

${glassRule(panelSel, container.panel, component.text, component.textMuted)}

${glassRule(inputSel, container.input, component.text, component.textMuted)}

${glassRule(headerSel, container.header, component.text, component.textMuted)}

${glassRule(popupSel, container.popup, component.text, component.textMuted)}

/* 用户区避免多层玻璃嵌套：内部容器全部清理，只留最外层。
   注意：[class*="menu"] 会匹配 .user-menu，所以这里用高特异性覆盖 popup 菜单项规则 */
.user-menu, [class*="user-menu"],
.user-menu *, [class*="user-menu"] *,
[class*="user"], [class*="profile"], [class*="account"], [class*="member"],
[class*="avatar"], [class*="status"], [class*="notification"], [class*="settings"] {
  background-color: transparent !important;
  background-image: none !important;
  border: none !important;
  box-shadow: none !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}

/* 弹出菜单容器加明显边框，强化轮廓 */
${popupSel} {
  border: 1px solid ${dark ? 'rgba(255,255,255,0.28)' : 'rgba(255,255,255,0.78)'} !important;
}

/* 语义化菜单项：默认透明，hover 加实底。
   不要写 ${popupSel} > div/li/button/a/span 这类通用子选择器，
   会命中 DUI/组件库菜单的嵌套容器造成套娃。 */
${popupSel} [role="menuitem"],
${popupSel} [class*="menuitem"],
${popupSel} [class*="menu-item"],
${popupSel} [class*="dropdown-item"],
${popupSel} [class*="select-item"] {
  background-color: transparent !important;
  color: ${component.text} !important;
  border-radius: 6px !important;
}
${popupSel} [role="menuitem"]:hover,
${popupSel} [role="menuitem"]:focus,
${popupSel} [class*="menuitem"]:hover,
${popupSel} [class*="menuitem"]:focus,
${popupSel} [class*="menu-item"]:hover,
${popupSel} [class*="menu-item"]:focus,
${popupSel} [class*="dropdown-item"]:hover,
${popupSel} [class*="dropdown-item"]:focus,
${popupSel} [class*="select-item"]:hover,
${popupSel} [class*="select-item"]:focus {
  background-color: ${dark ? 'rgba(40,44,58,0.85)' : 'rgba(255,255,255,0.92)'} !important;
  border-radius: 6px !important;
}

/* DUI/duim 组件库菜单专门处理：
   - 外层容器保留毛玻璃；
   - 中间 li/div/menu-item 等嵌套容器强制透明，防止父级背景条；
   - 最内层 button/a 默认加实底，确保文字清晰；
   - 文字用高对比纯色，避免 text-shadow 在实底上发虚。 */
[class*="dui-menu"], [class*="duim-menu"],
[class*="dui-dropdown"], [class*="duim-dropdown"] {
  background-color: ${dark ? 'rgba(18,20,28,0.92)' : 'rgba(255,255,255,0.94)'} !important;
  backdrop-filter: blur(20px) saturate(1.25) !important;
  -webkit-backdrop-filter: blur(20px) saturate(1.25) !important;
  border: 1px solid ${dark ? 'rgba(255,255,255,0.28)' : 'rgba(255,255,255,0.78)'} !important;
  border-radius: 12px !important;
}
[class*="dui-menu"] > li, [class*="duim-menu"] > li,
[class*="dui-menu"] > div, [class*="duim-menu"] > div,
[class*="dui-menu"] [class*="menu-item"], [class*="duim-menu"] [class*="menu-item"],
[class*="dui-menu"] [class*="option"], [class*="duim-menu"] [class*="option"],
[class*="dui-dropdown"] > li, [class*="duim-dropdown"] > li,
[class*="dui-dropdown"] > div, [class*="duim-dropdown"] > div,
[class*="dui-dropdown"] [class*="menu-item"], [class*="duim-dropdown"] [class*="menu-item"] {
  background-color: transparent !important;
  background-image: none !important;
  border: none !important;
  box-shadow: none !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
}
[class*="dui-menu"] button, [class*="duim-menu"] button,
[class*="dui-menu"] a, [class*="duim-menu"] a,
[class*="dui-dropdown"] button, [class*="duim-dropdown"] button,
[class*="dui-dropdown"] a, [class*="duim-dropdown"] a,
[class*="dui-menu"] [class*="item-content"], [class*="duim-menu"] [class*="item-content"],
[class*="dui-dropdown"] [class*="item-content"], [class*="duim-dropdown"] [class*="item-content"] {
  background-color: ${dark ? 'rgba(40,44,58,0.75)' : 'rgba(245,247,255,0.88)'} !important;
  color: ${dark ? '#FFFFFF' : '#0B0D14'} !important;
  border-radius: 8px !important;
  border: none !important;
  font-weight: 500 !important;
  text-shadow: none !important;
}
[class*="dui-menu"] button:hover, [class*="duim-menu"] button:hover,
[class*="dui-menu"] a:hover, [class*="duim-menu"] a:hover,
[class*="dui-dropdown"] button:hover, [class*="duim-dropdown"] button:hover,
[class*="dui-dropdown"] a:hover, [class*="duim-dropdown"] a:hover,
[class*="dui-menu"] [class*="item-content"]:hover, [class*="duim-menu"] [class*="item-content"]:hover,
[class*="dui-dropdown"] [class*="item-content"]:hover, [class*="duim-dropdown"] [class*="item-content"]:hover {
  background-color: ${dark ? 'rgba(60,66,86,0.92)' : 'rgba(255,255,255,0.98)'} !important;
}
/* DUI 菜单中的图标跟随文字颜色 */
[class*="dui-menu"] button svg, [class*="duim-menu"] button svg,
[class*="dui-menu"] a svg, [class*="duim-menu"] a svg,
[class*="dui-menu"] button [class*="icon"], [class*="duim-menu"] button [class*="icon"],
[class*="dui-menu"] a [class*="icon"], [class*="duim-menu"] a [class*="icon"] {
  color: inherit !important;
  fill: currentColor !important;
  stroke: currentColor !important;
}

/* 普通弹出菜单内文字加粗，仅在透明菜单项上保留轻微阴影 */
${popupSel} [role="menuitem"],
${popupSel} [class*="menuitem"],
${popupSel} [class*="menu-item"],
${popupSel} [class*="dropdown-item"],
${popupSel} [class*="select-item"] {
  font-weight: 600 !important;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.35) !important;
}

/* 消息流保持完全透明，让壁纸透出来 */
.group-messages, [class*="chatMessageContainer"], [class*="chatMessageBox"],
[class*="assistantRow"], [class*="assistantMessage"], [class*="userRow"],
.cb-markdown, .teams-content-wrapper, .teams-main-content {
  background: transparent !important;
  backdrop-filter: none !important;
  -webkit-backdrop-filter: none !important;
  border: none !important;
}`;
}

function buildComponentLayer(layers, dark) {
  const { component, tokens } = layers;
  const bp = component.buttonPrimary;
  const bs = component.buttonSecondary;
  const input = component.input;
  const sb = component.scrollbar;
  const chipBorder = dark ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.10)';
  const chipHoverBg = withAlpha(tokens.surface, dark ? 0.18 : 0.34);

  return `/* ===== 3. UI Component Layer 控件组件层 ===== */

/* Text system */
body, #app, .app, #root, .root, main, .main,
[class*="chat"], [class*="message"], [class*="panel"], [class*="overview"],
[class*="detail"], [class*="content"],
[class*="task"], [class*="project"], [class*="space"], [class*="conversation"],
[class*="nav"], [class*="nav-item"], [class*="menu-item"], [class*="list-item"] {
  color: ${component.text} !important;
}

p, span, div, label, li, button, input, textarea, select {
  color: inherit !important;
}

/* Icon color system: force icons to inherit theme text color */
svg, svg *, svg path, svg circle, svg rect, svg line, svg polyline, svg polygon {
  fill: currentColor !important;
  stroke: currentColor !important;
}
i, [class*="icon"], [class*="Icon"], [class*="svg-icon"], [class*="img-icon"],
[class*="avatar"] svg, [class*="nav"] svg {
  color: ${component.text} !important;
}
button[class*="primary"] i, button[class*="primary"] [class*="icon"],
[class*="accent"] i, [class*="accent"] [class*="icon"],
[class*="primary"] svg {
  color: ${component.text} !important;
}

/* Title / label text in lists (WorkBuddy uses hashed _title_ classes) */
[class*="_title_"],
.conversation-sidebar [class*="_title_"],
.conversation-section-label-text,
[class*="conversation-section-label"] {
  color: ${component.text} !important;
}
/* 提升特异性，覆盖 WorkBuddy 原生的 .conversation-agent-card [class*="title"]:not(...) !important */
#root .conversation-sidebar [class*="_title_"],
#root .conversation-list [class*="_title_"] {
  color: ${component.text} !important;
}
/* Timestamps / meta text in lists */
[class*="_timestamp_"], [class*="timestamp"], [class*="meta"] {
  color: ${component.textMuted} !important;
}

/* Base containers should not carry fills or outlines */
p, div, span, label, li {
  background-color: transparent !important;
  border: none !important;
}

a, a:link, a:visited, [class*="link"] {
  color: ${component.link} !important;
}
a:hover, [class*="link"]:hover {
  color: ${tokens.secondary} !important;
}

[class*="muted"], [class*="secondary"], [class*="desc"], [class*="subtitle"],
[class*="placeholder"], [class*="timestamp"], [class*="caption"] {
  color: ${component.textMuted} !important;
}

::placeholder, [class*="placeholder"] {
  color: ${component.textPlaceholder} !important;
}

/* Primary buttons: accent outline/text, filled on hover */
button[class*="primary"], [class*="button"][class*="primary"], .vs-button-primary, .monaco-button,
button[type="submit"], [role="button"][class*="primary"] {
  background: ${bp.bg} !important;
  color: ${bp.text} !important;
  border: 1px solid ${bp.border} !important;
  border-radius: 10px !important;
  box-shadow: none !important;
  transition: all 0.15s ease !important;
}
button[class*="primary"]:hover, [class*="button"][class*="primary"]:hover, .vs-button-primary:hover, .monaco-button:hover,
button[type="submit"]:hover, [role="button"][class*="primary"]:hover {
  background: ${bp.hoverBg} !important;
  color: ${bp.hoverText} !important;
  border-color: ${bp.hoverBg} !important;
}

/* Default buttons: clean transparent with subtle border, glass on hover */
button:not([class*="primary"]):not([type="submit"]), [role="button"]:not([class*="primary"]),
[class*="button"]:not([class*="primary"]), [class*="_button_"] {
  background: transparent !important;
  color: ${bs.text} !important;
  border: 1px solid ${bs.border} !important;
  border-radius: 10px !important;
  transition: all 0.15s ease !important;
}
button:not([class*="primary"]):not([type="submit"]):hover, [role="button"]:not([class*="primary"]):hover,
[class*="button"]:not([class*="primary"]):hover, [class*="_button_"]:hover {
  background: ${bs.hoverBg} !important;
  border-color: ${withAlpha(tokens.surface, dark ? 0.18 : 0.28)} !important;
}

[class*="button"][class*="secondary"], .vs-button-secondary {
  background: transparent !important;
  color: ${bs.text} !important;
  border: 1px solid ${bs.border} !important;
  border-radius: 10px !important;
}
[class*="button"][class*="secondary"]:hover, .vs-button-secondary:hover {
  background: ${bs.hoverBg} !important;
  color: ${bs.hoverText} !important;
}

/* Inputs / textareas: glass instead of solid dark */
input, textarea, select,
[class*="input"], [class*="textarea"], [class*="search"], [class*="prompt"],
.monaco-input, .vs-input,
.monaco-workbench .monaco-editor .inputarea,
.monaco-workbench .suggest-widget, .monaco-workbench .quick-input-widget {
  background: ${input.bg} !important;
  color: ${input.text} !important;
  border: 1px solid ${input.border} !important;
  border-radius: 12px !important;
}
input:focus, textarea:focus, [class*="input"]:focus, [class*="textarea"]:focus {
  border-color: ${input.focusBorder} !important;
  box-shadow: 0 0 0 3px ${withAlpha(input.focusBorder, 0.22)} !important;
}

/* Dividers & borders */
hr, [class*="divider"], [class*="separator"] {
  border-color: ${component.divider} !important;
  background: ${component.divider} !important;
}

/* Cards / bubbles: transparent by default, faint glass on hover */
[class*="card"], [class*="bubble"] {
  background: transparent !important;
  border: none !important;
  color: ${component.text} !important;
}
[class*="card"]:hover, [class*="bubble"]:hover {
  background: ${chipHoverBg} !important;
}

/* Tags / badges / chips / capsules: NO border, NO fill by default.
   User feedback: the 1px outline reads as a "background bar" next to siblings,
   so we drop it entirely and only show a faint hover tint. */
[class*="tag"], [class*="badge"], [class*="chip"], [class*="pill"], [class*="category"] {
  background: transparent !important;
  border: none !important;
  color: ${component.text} !important;
  border-radius: 999px !important;
  padding: 2px 10px !important;
  box-shadow: none !important;
  transition: all 0.15s ease !important;
}
[class*="tag"]:hover, [class*="badge"]:hover, [class*="chip"]:hover,
[class*="pill"]:hover, [class*="category"]:hover {
  background: ${chipHoverBg} !important;
}

/* Delivery / artifact / summary panels & tables inside chat/main content.
   WorkBuddy renders these with solid backgrounds (white/brown) which clash with skins. */
#root .main-content table, #root .main-content thead, #root .main-content tbody,
#root .main-content tr, #root .main-content td, #root .main-content th,
#root .cb-markdown table, #root .cb-markdown thead, #root .cb-markdown tbody,
#root .cb-markdown tr, #root .cb-markdown td, #root .cb-markdown th,
#root .teams-main-content [class*="table"], #root .teams-main-content [class*="summary"],
#root .teams-main-content [class*="delivery"], #root .teams-main-content [class*="overview"],
#root .teams-main-content [class*="artifact"], #root .teams-main-content [class*="attachment"],
#root .teams-main-content [class*="file-card"], #root .teams-main-content [class*="resource"],
#root .teams-main-content [class*="result"], #root .teams-main-content [class*="card"],
#root .cb-markdown [class*="card"], #root .cb-markdown [class*="artifact"],
#root .cb-markdown [class*="summary"], #root .cb-markdown [class*="delivery"] {
  background-color: ${withAlpha(tokens.surface, dark ? 0.20 : 0.52)} !important;
  color: ${component.text} !important;
  border-color: ${component.border} !important;
  backdrop-filter: blur(14px) saturate(1.1) !important;
  -webkit-backdrop-filter: blur(14px) saturate(1.1) !important;
}
/* Chat message bubbles: glass so wallpaper shows but text stays readable */
#root [class*="userMessageBubble"],
#root [class*="assistantMessageBubble"],
#root [class*="messageBubble"],
#root [class*="message-bubble"] {
  background-color: ${withAlpha(tokens.surface, dark ? 0.32 : 0.62)} !important;
  color: ${component.text} !important;
  border: none !important;
  box-shadow: none !important;
  backdrop-filter: blur(14px) saturate(1.1) !important;
  -webkit-backdrop-filter: blur(14px) saturate(1.1) !important;
}

/* Code / text preview blocks: header + pre wrapper. Keep inner hljs syntax highlighting visible. */
#root .cb-markdown-pre-container,
#root .cb-markdown-pre-wrapper,
#root .cb-markdown-pre,
#root .cb-markdown-pre__header,
#root [class*="markdown-pre"], #root [class*="code-block"], #root [class*="codeBlock"] {
  background-color: ${withAlpha(tokens.surface, dark ? 0.28 : 0.58)} !important;
  color: ${component.text} !important;
  border-color: ${component.border} !important;
  backdrop-filter: blur(14px) saturate(1.1) !important;
  -webkit-backdrop-filter: blur(14px) saturate(1.1) !important;
}
#root .cb-markdown-pre__header,
#root [class*="markdown-pre"][class*="header"] {
  border-bottom: 1px solid ${component.border} !important;
}
#root .cb-markdown-pre pre,
#root .cb-markdown-pre code {
  background-color: transparent !important;
  color: inherit !important;
}

/* File attachment tags/pills inside messages */
#root [class*="fileTag"],
#root [class*="file-tag"],
#root [class*="attachment-tag"],
#root [class*="resource-tag"] {
  background-color: ${withAlpha(tokens.surface, dark ? 0.25 : 0.55)} !important;
  color: ${component.text} !important;
  border: 1px solid ${component.border} !important;
  border-radius: 999px !important;
  backdrop-filter: blur(10px) saturate(1.05) !important;
  -webkit-backdrop-filter: blur(10px) saturate(1.05) !important;
}

/* Composer / prompt main area */
#root [class*="mainArea"], #root [class*="main-area"],
#root [class*="composer"], #root [class*="prompt-area"],
#root [class*="inputArea"], #root [class*="input-area"] {
  background-color: ${withAlpha(tokens.surface, dark ? 0.30 : 0.60)} !important;
  border: 1px solid ${component.border} !important;
  color: ${component.text} !important;
  backdrop-filter: blur(16px) saturate(1.15) !important;
  -webkit-backdrop-filter: blur(16px) saturate(1.15) !important;
}

/* Plan / task detail cards rendered inside chat */
#root [class*="plan-task-detail"], #root [class*="task-detail"],
#root [class*="plan-card"], #root [class*="task-card"] {
  background-color: ${withAlpha(tokens.surface, dark ? 0.24 : 0.54)} !important;
  color: ${component.text} !important;
  border: 1px solid ${component.border} !important;
  backdrop-filter: blur(14px) saturate(1.1) !important;
  -webkit-backdrop-filter: blur(14px) saturate(1.1) !important;
}

/* Scrollbars */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}
::-webkit-scrollbar-track {
  background: ${sb.track};
}
::-webkit-scrollbar-thumb {
  background: ${sb.thumb};
  border-radius: 4px;
}
::-webkit-scrollbar-thumb:hover {
  background: ${sb.hover};
}`;
}

function buildTokenLayer(layers) {
  const { tokens } = layers;
  return `/* ===== 4. Color Token Layer 主题 Token 层 ===== */
/* 将 Token 写入更多通用变量名，供 WorkBuddy 不同版本读取 */
:root {
  --wb-primary: ${tokens.primary};
  --wb-secondary: ${tokens.secondary};
  --wb-success: ${tokens.success};
  --wb-warning: ${tokens.warning};
  --wb-error: ${tokens.error};
  --wb-surface-solid: ${tokens.surfaceSolid};
  --wb-background: ${tokens.background};
  --wb-foreground: ${tokens.foreground};
}`;
}

function buildAssetLayer(layers) {
  const assets = layers.assets || {};
  if (!assets.animations || assets.animations.length === 0) {
    return `/* ===== 5. Assets Layer 装饰资源层 ===== */
/* 本皮肤未启用额外装饰资源 */`;
  }

  // 预留常用动画类
  const animMap = {
    'shimmer': `@keyframes wb-shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}
.wb-anim-shimmer {
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
  background-size: 200% 100%;
  animation: wb-shimmer 2.5s infinite linear;
}`,
    'gradient-flow': `@keyframes wb-gradient-flow {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}
.wb-anim-gradient-flow {
  background: linear-gradient(270deg, var(--wb-primary), var(--wb-secondary), var(--wb-primary));
  background-size: 200% 200%;
  animation: wb-gradient-flow 6s ease infinite;
}`
  };

  const blocks = assets.animations
    .map(a => animMap[a] || `/* unknown animation: ${a} */`)
    .join('\n\n');

  return `/* ===== 5. Assets Layer 装饰资源层 ===== */\n${blocks}`;
}

function main() {
  const [skinJsonPath, outPath] = process.argv.slice(2);
  if (!skinJsonPath || !outPath) {
    console.error('用法：node build-theme-css.js <skin.json> <theme.css>');
    process.exit(1);
  }

  const skin = JSON.parse(fs.readFileSync(skinJsonPath, 'utf8'));
  const layers = deriveLayers(skin);

  const css = [
    `/* WorkBuddy Skin: ${skin.name || 'Untitled'} */`,
    '/* Auto-generated by workbuddy-skin-generator Skill (v2.0 five-layer architecture) */',
    '',
    buildTokenVars(layers, skin.theme === 'dark'),
    buildContainerLayer(layers, skin.theme === 'dark'),
    buildComponentLayer(layers, skin.theme === 'dark'),
    buildTokenLayer(layers),
    buildAssetLayer(layers),
    // Background layer goes LAST: it clears every opaque host shell and installs the sole
    // artwork owner. Emitting it earlier lets the glass rules paint the shells solid again.
    buildBackgroundLayer(layers)
  ].join('\n\n') + '\n';

  fs.writeFileSync(outPath, css, 'utf8');
  console.log(`theme.css written to ${outPath}`);
}

main();
