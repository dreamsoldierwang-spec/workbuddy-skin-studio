#!/usr/bin/env node
// 将皮肤文件夹打包为 .wbskin（本质为 zip）
// 用法：node pack-wbskin.js <皮肤文件夹> [输出.wbskin路径]

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

function main() {
  const [sourceDir, outFile] = process.argv.slice(2);
  if (!sourceDir) {
    console.error('用法：node pack-wbskin.js <皮肤文件夹> [输出.wbskin路径]');
    process.exit(1);
  }

  const absSource = path.resolve(sourceDir);
  if (!fs.existsSync(path.join(absSource, 'skin.json'))) {
    console.error('错误：源文件夹缺少 skin.json');
    process.exit(1);
  }

  const skin = JSON.parse(fs.readFileSync(path.join(absSource, 'skin.json'), 'utf8'));
  const defaultOut = path.join(path.dirname(absSource), `${skin.id || 'skin'}.wbskin`);
  const output = outFile ? path.resolve(outFile) : defaultOut;

  // 临时 zip 路径
  const tmpZip = output + '.zip';
  if (fs.existsSync(tmpZip)) fs.unlinkSync(tmpZip);
  if (fs.existsSync(output)) fs.unlinkSync(output);

  // 使用系统 zip 命令打包
  const cmd = `cd "${absSource}" && zip -r "${tmpZip}" . -x "*.DS_Store"`;
  execSync(cmd, { stdio: 'inherit' });

  fs.renameSync(tmpZip, output);
  console.log(`已打包：${output}`);
}

main();
