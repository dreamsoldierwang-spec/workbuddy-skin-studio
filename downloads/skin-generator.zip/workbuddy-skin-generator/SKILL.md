---
name: workbuddy-skin-generator
description: Generate WorkBuddy skin packages (.wbskin) from an uploaded image or color palette. Uses a five-layer architecture (background, container glass, UI components, color tokens, assets) to produce visually polished themes with background images, frosted-glass panels, readable text, and consistent color tokens.
agent_created: true
---

# WorkBuddy 皮肤生成 Skill

## 用途

当用户想要为 WorkBuddy 制作一套皮肤、主题或外观包时使用。用户通常会上传一张参考图（电影海报、动漫角色、风景照等），要求提取配色并生成可导入 WorkBuddy 的皮肤文件。

触发语句示例：
- "帮我生成一套 WorkBuddy 皮肤"
- "上传这张图做成 .wbskin 皮肤包"
- "根据这张图片生成蜘蛛侠主题"
- "做一个深色/浅色的 WorkBuddy 皮肤"

## 输出格式

最终交付物是一个 `.wbskin` 文件，结构如下：

```
<name>.wbskin (zip)
├── skin.json
├── theme.css
└── images/
    └── hero.png
```

`.wbskin` 本质为 ZIP，仅改后缀便于识别。

详细规范见 `references/wbskin-spec.md`（v2.0 五层架构）。

## 五层皮肤架构

皮肤按以下五层生成，每层职责清晰：

1. **Background Layer 全局背景层**
   - 全窗口最底层画布，氛围核心。
   - 形式：图片壁纸或 CSS 渐变。
   - 支持透明度、模糊、缩放、平铺、叠色。
   - 自动从背景图提取主色调供给上层。

2. **Container Glass Layer 布局容器面板层（毛玻璃）**
   - 界面各大分区的半透明底板。
   - 覆盖：左侧侧边栏、中间对话主面板、右侧结果预览面板、顶部标题栏、底部输入框、弹窗浮层。
   - 使用 `backdrop-filter: blur() saturate()` 实现毛玻璃，背景图从半透明面板中透出。
   - 可配置：透明度、模糊强度、饱和度、圆角、边框、阴影。

3. **UI Component Layer 控件组件层**
   - 所有交互元素样式。
   - 文字体系（主文本、次要文本、placeholder、链接）、按钮（主/次/hover/激活）、表单（输入框/下拉/滚动条）、卡片、标签、分割线。

4. **Color Token Layer 主题 Token 层**
   - 整套皮肤的色彩基准。
   - 主色、辅助色、成功/警告/错误色、面板底色、前景文字色。
   - 自动根据 `theme: dark/light` 生成深浅两套变量。

5. **Assets Layer 装饰资源层**
   - 可选附加素材：插画、LOGO、水印、CSS 动画（微光、渐变流动等）。

## 工作流程

1. **接收输入**：让用户上传一张参考图（或手动给出主色/辅色/底色/文字色与深浅主题）。
2. **分析取色**：
   - 使用图像理解能力描述图片主色调；
   - 推荐一套与图片协调的配色（accent / secondary / surface / text / textMuted / inputBg）。
   - 判断适合 `dark` 还是 `light` 主题。
3. **生成 skin.json**：按 `references/wbskin-spec.md` 的 v2.0 schema 填写，包含 `colors` 与 `layers`。
4. **生成 theme.css**：
   - 调用 `scripts/build-theme-css.js <skin.json> <theme.css>` 生成；
   - 该脚本会基于五层配置生成：背景层 + 毛玻璃容器层 + 控件层 + Token 变量层 + 装饰层。
5. **处理背景图**：
   - 将用户上传的参考图保存为 `images/hero.png`。
   - **可读性优先**：如果原图过亮、过饱和或细节复杂，直接使用会导致文字被淹没。此时应基于原图重新生成一张**暗调、模糊、抽象化的背景图**（保留主题色调但降低干扰），再存为 `images/hero.png`。
6. **打包 .wbskin**：
   - 调用 `scripts/pack-wbskin.js <皮肤文件夹> [输出路径]` 生成最终 `.wbskin` 文件。
7. **交付**：把 `.wbskin` 文件路径告诉用户，并说明用「WorkBuddy 皮肤管理器」App 双击导入或拖拽导入即可应用。

## 配色建议

- **accent**：图片中最鲜明、饱和度最高的颜色，用于选中态、链接、焦点、hover 填充。不要大面积用于所有普通按钮。
- **secondary**：accent 的邻近色或对比色，用于悬停、滚动条、次要高亮。
- **surface**：整体底色。dark 主题用深灰/黑/棕，light 主题用浅灰/白。
- **surfaceTransparent**：可选，surface 的半透明版本。v2.0 模板会自动推导毛玻璃面板色，无需手动指定。
- **text**：与 surface 高对比的主文字色。dark 主题用近白，light 主题用近黑。
- **textMuted**：次要文字色，比 text 稍弱。
- **inputBg**：输入框背景，dark 主题用 `rgba(0,0,0,0.45)`，light 主题用 `rgba(255,255,255,0.72)`。

## 注意事项

- **背景图必须可见**：HTML/body 与所有根容器（`#app`/`#root`/`.main` 等）必须设为 `background: transparent`，否则背景图会被盖住。
- **毛玻璃核心**：背景图在 `html::before/body::before` 层，容器使用低透明度背景（dark 主题 0.32–0.55）+ `backdrop-filter: blur(28px) saturate(1.25)`，让背景图透过面板明显透出。
- **按钮配色**：普通按钮默认使用半透明玻璃背景，不要全部填充 accent；只有带 `primary` 类或 hover 时才填充强调色，避免界面刺眼。
- **文字可读性**：light 主题用深色文字，dark 主题用浅色文字；主文字与毛玻璃面板背景必须保持高对比。
- **深色主题毛玻璃**：容器默认使用 `surface` 色的半透明版本（如 `rgba(31,10,0,0.45)`），而不是白色半透明，避免风格冲突。
- **皮肤 ID** 只能包含小写字母、数字、连字符，不要用中文或空格。
- 最终应提醒用户：用「WorkBuddy 皮肤管理器」App 导入 `.wbskin`，点击应用即可换肤。
